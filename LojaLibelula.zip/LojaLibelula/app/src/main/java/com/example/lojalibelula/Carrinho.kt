package com.example.lojalibelula

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity

class Carrinho : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_carrinho)

        // Clicar no colar libelula dentro do carrinho.xml e ir para a tela libelula.xml
        val itemLibelula = findViewById<View>(R.id.itemLibelula)
        itemLibelula?.setOnClickListener {
            val intent = Intent(this, libelula::class.java)
            startActivity(intent)
        }

        val btnNavHome = findViewById<View>(R.id.btnNavHome)
        btnNavHome?.setOnClickListener {
            val intent = Intent(this, HomeActivity::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
            startActivity(intent)
        }

        // Navegação para a tela de Perfil
        val btnNavPerfil = findViewById<View>(R.id.btnNavPerfil)
        btnNavPerfil?.setOnClickListener {
            val intent = Intent(this, PerfilActivity::class.java)
            startActivity(intent)
        }

        val btnBack = findViewById<View>(R.id.btnBack)
        btnBack?.setOnClickListener {
            finish()
        }
    }
}