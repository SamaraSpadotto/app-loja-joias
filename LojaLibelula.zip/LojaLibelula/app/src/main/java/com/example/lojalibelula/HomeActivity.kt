package com.example.lojalibelula

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity

class HomeActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)

        // Clique no item Colar Libélula desativado conforme solicitado
        val layoutLibelula = findViewById<View>(R.id.layoutLibelula)
        layoutLibelula?.setOnClickListener(null)
        layoutLibelula?.isClickable = false

        // Clique no botão Carrinho do menu inferior
        val btnCarrinhoMenu = findViewById<View>(R.id.btnNavCarrinho)
        btnCarrinhoMenu?.setOnClickListener {
            val intent = Intent(this, Carrinho::class.java)
            startActivity(intent)
        }

        // Navegação para a tela de Perfil
        val btnNavPerfil = findViewById<View>(R.id.btnNavPerfil)
        btnNavPerfil?.setOnClickListener {
            val intent = Intent(this, PerfilActivity::class.java)
            startActivity(intent)
        }
    }
}