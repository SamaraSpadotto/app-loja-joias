package com.example.lojalibelula

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInClient
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.gms.common.api.ApiException
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.GoogleAuthProvider
import com.google.firebase.firestore.FirebaseFirestore

class MainActivity : AppCompatActivity() {

    private lateinit var auth: FirebaseAuth
    private lateinit var googleSignInClient: GoogleSignInClient
    private val db = FirebaseFirestore.getInstance()

    private val googleSignInLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val task = GoogleSignIn.getSignedInAccountFromIntent(result.data)
        try {
            val account = task.getResult(ApiException::class.java)!!
            firebaseAuthWithGoogle(account.idToken!!)
        } catch (e: ApiException) {
            Toast.makeText(this, "Falha no login: ${e.statusCode}", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        // Inicializa o Firebase explicitamente para evitar o erro de inicialização
        FirebaseApp.initializeApp(this)
        
        setContentView(R.layout.telainicio)

        auth = FirebaseAuth.getInstance()

        // Configuração do Google Sign-In
        val gso = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
            .requestIdToken("1078641238242-mvc8d1q69oon3qfmajk76v9mikvnh3e8.apps.googleusercontent.com")
            .requestEmail()
            .build()

        googleSignInClient = GoogleSignIn.getClient(this, gso)

        // Clique no botão do Google
        val btnGoogle = findViewById<Button>(R.id.btnGoogle)
        btnGoogle?.setOnClickListener {
            // Força o logout do Google antes de iniciar o fluxo para sempre exibir a caixa de seleção de contas
            googleSignInClient.signOut().addOnCompleteListener {
                val signInIntent = googleSignInClient.signInIntent
                googleSignInLauncher.launch(signInIntent)
            }
        }
    }

    private fun firebaseAuthWithGoogle(idToken: String) {
        val credential = GoogleAuthProvider.getCredential(idToken, null)
        auth.signInWithCredential(credential)
            .addOnCompleteListener(this) { task ->
                if (task.isSuccessful) {
                    val user = auth.currentUser
                    if (user != null) {
                        // --- TAREFA: "C" do CRUD (Create) ---
                        val userDocRef = db.collection("usuarios").document(user.uid)
                        userDocRef.get().addOnSuccessListener { document ->
                            if (!document.exists()) {
                                val dadosIniciais = hashMapOf(
                                    "apelido" to "insira seu apelido aqui!",
                                    "celular" to "(54) 1234-5678",
                                    "endereco" to "rua das flores, 12345-678, Apto. 505, 123.",
                                    "email" to user.email,
                                    "fotoUrl" to (user.photoUrl?.toString() ?: "")
                                )
                                userDocRef.set(dadosIniciais).addOnCompleteListener {
                                    Toast.makeText(this, "Login realizado com sucesso!", Toast.LENGTH_SHORT).show()
                                    startActivity(Intent(this, HomeActivity::class.java))
                                    finish()
                                }
                            } else {
                                Toast.makeText(this, "Login realizado com sucesso!", Toast.LENGTH_SHORT).show()
                                startActivity(Intent(this, HomeActivity::class.java))
                                finish()
                            }
                        }.addOnFailureListener {
                            Toast.makeText(this, "Login realizado com sucesso!", Toast.LENGTH_SHORT).show()
                            startActivity(Intent(this, HomeActivity::class.java))
                            finish()
                        }
                    } else {
                        Toast.makeText(this, "Login realizado com sucesso!", Toast.LENGTH_SHORT).show()
                        startActivity(Intent(this, HomeActivity::class.java))
                        finish()
                    }
                } else {
                    Toast.makeText(this, "Erro de autenticação no Firebase.", Toast.LENGTH_SHORT).show()
                }
            }
    }
}
