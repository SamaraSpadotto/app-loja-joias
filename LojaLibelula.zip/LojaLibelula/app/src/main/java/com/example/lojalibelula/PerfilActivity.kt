package com.example.lojalibelula

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.bumptech.glide.Glide
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

class PerfilActivity : AppCompatActivity() {

    private val auth = FirebaseAuth.getInstance()
    private val db = FirebaseFirestore.getInstance()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_perfil)

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        val imgFotoPerfil = findViewById<ImageView>(R.id.imgFotoPerfil)
        val tvEmail = findViewById<TextView>(R.id.tvEmail)
        val etApelido = findViewById<EditText>(R.id.etApelido)
        val etCelular = findViewById<EditText>(R.id.etCelular)
        val etEndereco = findViewById<EditText>(R.id.etEndereco)
        val btnSalvar = findViewById<View>(R.id.btnSalvarPerfil)
        val btnDeletar = findViewById<View>(R.id.btnDeletarPerfil)
        val btnVoltar = findViewById<View>(R.id.btnVoltar)

        val user = auth.currentUser
        if (user != null) {
            // --- TAREFA: "R" do CRUD (Read) ---
            // Consulta o Firestore no documento do usuário logado (usuarios/UID)
            db.collection("usuarios").document(user.uid).get()
                .addOnSuccessListener { document ->
                    if (document.exists()) {
                        // Preenche automaticamente os valores nos respectivos campos de texto da tela
                        tvEmail.text = document.getString("email")
                        etApelido.setText(document.getString("apelido"))
                        etCelular.setText(document.getString("celular"))
                        etEndereco.setText(document.getString("endereco"))
                        
                        // Busca e preenche a foto de perfil
                        val fotoUrl = document.getString("fotoUrl")
                        if (!fotoUrl.isNullOrEmpty()) {
                            Glide.with(this).load(fotoUrl).circleCrop().into(imgFotoPerfil)
                        } else {
                            // Fallback para a foto da conta do Google logada
                            user.photoUrl?.let {
                                Glide.with(this).load(it).circleCrop().into(imgFotoPerfil)
                            }
                        }
                    } else {
                        // Caso o documento não exista no banco (primeiro acesso), exibe o que temos do Auth
                        tvEmail.text = user.email
                        user.photoUrl?.let {
                            Glide.with(this).load(it).circleCrop().into(imgFotoPerfil)
                        }
                    }
                }
                .addOnFailureListener {
                    Toast.makeText(this, "Erro ao carregar dados do perfil", Toast.LENGTH_SHORT).show()
                }
        }

        // --- TAREFA: "U" do CRUD (Update) com Confirmação ---
        btnSalvar?.setOnClickListener {
            if (user != null) {
                AlertDialog.Builder(this)
                    .setTitle("Confirmar Alterações")
                    .setMessage("Você tem certeza que deseja salvar as alterações?")
                    .setPositiveButton("Sim") { _, _ ->
                        val dados = hashMapOf(
                            "apelido" to etApelido.text.toString(),
                            "celular" to etCelular.text.toString(),
                            "endereco" to etEndereco.text.toString(),
                            "email" to user.email
                        )

                        db.collection("usuarios").document(user.uid)
                            .update(dados as Map<String, Any>)
                            .addOnSuccessListener {
                                Toast.makeText(this, "Perfil atualizado com sucesso!", Toast.LENGTH_SHORT).show()
                            }
                            .addOnFailureListener {
                                Toast.makeText(this, "Erro ao salvar dados", Toast.LENGTH_SHORT).show()
                            }
                    }
                    .setNegativeButton("Não", null)
                    .show()
            }
        }

        // --- TAREFA: "D" do CRUD (Delete) ---
        btnDeletar?.setOnClickListener {
            if (user != null) {
                val uid = user.uid
                db.collection("carrinho")
                    .whereEqualTo("usuarioId", uid)
                    .get()
                    .addOnSuccessListener { querySnapshot ->
                        val batch = db.batch()
                        for (doc in querySnapshot) {
                            batch.delete(doc.reference)
                        }
                        batch.commit().addOnCompleteListener {
                            db.collection("usuarios").document(uid).delete()
                                .addOnCompleteListener {
                                    val gso = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN).build()
                                    val googleSignInClient = GoogleSignIn.getClient(this, gso)
                                    googleSignInClient.signOut().addOnCompleteListener {
                                        user.delete().addOnCompleteListener { task ->
                                            if (task.isSuccessful) {
                                                Toast.makeText(this, "Conta excluída com sucesso!", Toast.LENGTH_SHORT).show()
                                            } else {
                                                auth.signOut()
                                            }
                                            val intent = Intent(this, MainActivity::class.java)
                                            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                                            startActivity(intent)
                                            finish()
                                        }
                                    }
                                }
                        }
                    }
            }
        }

        btnVoltar?.setOnClickListener { finish() }

        // Navegação
        findViewById<View>(R.id.btnNavHome)?.setOnClickListener {
            val intent = Intent(this, HomeActivity::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
            startActivity(intent)
        }
        
        findViewById<View>(R.id.btnNavCarrinho)?.setOnClickListener {
            startActivity(Intent(this, Carrinho::class.java))
        }
    }
}