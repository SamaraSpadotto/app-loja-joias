package com.example.lojalibelula

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

class libelula : AppCompatActivity() {

    private val db = FirebaseFirestore.getInstance()
    private val auth = FirebaseAuth.getInstance()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_libelula)
        
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // Adicionar ao carrinho (Firebase)
        val btnAdicionarCarrinho = findViewById<View>(R.id.btnAdicionarCarrinho)
        btnAdicionarCarrinho?.setOnClickListener {
            val user = auth.currentUser
            if (user != null) {
                val item = hashMapOf(
                    "produto" to "Colar Libélula",
                    "preco" to 89.90,
                    "usuarioId" to user.uid
                )
                db.collection("carrinho")
                    .add(item)
                    .addOnSuccessListener {
                        Toast.makeText(this, "Adicionado ao carrinho!", Toast.LENGTH_SHORT).show()
                    }
            }
        }

        // Botão Comprar agora direciona para a tela de pagamento
        val btnComprarAgora = findViewById<View>(R.id.btnComprarAgora)
        btnComprarAgora?.setOnClickListener {
            val intent = Intent(this, pagamento::class.java)
            startActivity(intent)
        }

        val btnVoltar = findViewById<View>(R.id.btnVoltar)
        btnVoltar?.setOnClickListener {
            finish()
        }

        val btnNavHome = findViewById<View>(R.id.btnNavHome)
        btnNavHome?.setOnClickListener {
            val intent = Intent(this, HomeActivity::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
            startActivity(intent)
        }

        // Navegação para a tela de Perfil
        val btnNavPerfil = findViewById<View>(R.id.btnNavPerfil)
        btnNavPerfil?.setOnClickListener {
            val intent = Intent(this, PerfilActivity::class.java)
            startActivity(intent)
        }
        
        // Navegação para o Carrinho
        val btnNavCarrinho = findViewById<View>(R.id.btnNavCarrinho)
        btnNavCarrinho?.setOnClickListener {
            val intent = Intent(this, Carrinho::class.java)
            startActivity(intent)
        }
    }
}