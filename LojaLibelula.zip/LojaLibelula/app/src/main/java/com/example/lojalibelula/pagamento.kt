package com.example.lojalibelula

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class pagamento : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_pagamento)
        
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // Botão voltar no cabeçalho retorna para a tela anterior
        val btnBack = findViewById<View>(R.id.btnBack)
        btnBack?.setOnClickListener {
            finish()
        }

        // Ícone Home no menu inferior retorna para a tela Home
        val btnNavHome = findViewById<View>(R.id.btnNavHome)
        btnNavHome?.setOnClickListener {
            val intent = Intent(this, HomeActivity::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
            startActivity(intent)
        }

        // Ícone Perfil no menu inferior
        val btnNavPerfil = findViewById<View>(R.id.btnNavPerfil)
        if (btnNavPerfil == null) {
            // No layout activity_pagamento.xml, o ID do container do perfil não está definido no LinearLayout, 
            // mas o ImageView tem id 'perfil'. Vou tentar encontrar pelo container se existir ou pelo ícone.
            // Olhando o XML, o container do perfil não tem ID, mas o ícone tem id 'perfil'.
            findViewById<View>(R.id.perfil)?.setOnClickListener {
                startActivity(Intent(this, PerfilActivity::class.java))
            }
        } else {
            btnNavPerfil.setOnClickListener {
                startActivity(Intent(this, PerfilActivity::class.java))
            }
        }
    }
}